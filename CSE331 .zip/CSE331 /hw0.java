public class hw0 {
	public static void do(int[] b) {
		int i = 0;
		int j = i + 1;
		while (i < b.length - 1) {
			if (b[j] < b[i]) {
				swap(b[i], b[j]);
				i = 0;
			} else {
				i++;
			}
		}
	}
}

/* we first made to index of the array - i and j. 
we make b.length - 1 in the while loop is because the pairs number (former and latter) is one less than the array length.
b[j] represents the element after the element b[i]. 
so if the latter number is smaller than the former, we swap these two element. 
And make the index to the beginning of the array. 
So we can check if the array is in the right order after swapping. 
If not, we will swap two elements again that we find by if statement, and back the beginning of the array again.
If swap to the correct order, the while loop will end that i will exceed the limit. 
 

