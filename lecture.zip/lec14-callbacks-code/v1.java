
// stubs: Color and Dictionary don't work; we just want the rest to type-check
class Color {
    public Color(String s) {}
}
class Dictionary { 
    public static Dictionary findDictionary(String language) { return null; /*...*/ }
    public boolean contains(String s) { return true; /*...*/ }
    /*...*/
}

// a real class for styled text would have much more but this gets the idea across.
class StyledWord {
    private StringBuffer text  = new StringBuffer();
    private Color        color = new Color("black");
    public StyledWord() { }
    public void addLetter(char c, int position) { 
        text.insert(position,c); 
    }
    public void deleteLetter(int position) { 
        text.delete(position,position+1); 
    }
    public String getText() {
        return new String(text);
    }
    public Color getColor() {
        return color;
    }
    public void setColor(Color c) {
        color = c;
    }
}

/* Here we use composition, but subtyping has the same
   coupling issues where we need to spell-check after any word change, so
   any change or additions to StyledWord that could change the word
   would require changing SpellcheckedStyledWord and NoQs.

   Also this v1 doesn't let us spell-check /and/ disallow Qs.

   Bad design to high coupling and lack of composability..
 */
class SpellcheckedStyledWord {
    private Dictionary dictionary;
    private StyledWord word = new StyledWord();
    public SpellcheckedStyledWord(String language) {
        dictionary = Dictionary.findDictionary(language);
    }
    private void performSpellcheck() {
        if(dictionary.contains(word.getText())) {
            word.setColor(new Color("black"));
        } else {
            word.setColor(new Color("red"));
        }
    }
    public void addLetter(char c, int position) {
        word.addLetter(c,position);
        performSpellcheck();
    }
    public void deleteLetter(int position) {
        word.deleteLetter(position);
        performSpellcheck();
    }
    public String getText() {
        return word.getText();
    }
    public Color getColor() {
        return word.getColor();
    }
    public void setColor(Color c) {
        word.setColor(c);
    }
}

// another possible wrapper class for StyledWord not used by main but with the
// same coupling issues
class NoQsStyledWord {
    private StyledWord word = new StyledWord();
    public NoQsStyledWord() {}
    public void addLetter(char c, int position) {
        if(c != 'Q') {
            word.addLetter(c,position);
        }
    }
    public void deleteLetter(int position) {
        word.deleteLetter(position);
    }
    public String getText() {
        return word.getText();
    }
    public Color getColor() {
        return word.getColor();
    }
    public void setColor(Color c) {
        word.setColor(c);
    }
}

class Main {
    public static void main(String[] args) {
        SpellcheckedStyledWord w = new SpellcheckedStyledWord("English");
        // ... use w in various methods in the application
    }
}