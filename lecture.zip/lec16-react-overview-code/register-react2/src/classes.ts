// Quarters for which we have information.
export const QUARTERS = ["Fall 2021", "Winter 2022"];

// Classes available in each quarter.
export const CLASSES: Map<string, string[]> = new Map([
    ["Fall 2021", ["CSE 341", "CSE 344", "CSE 421", "CSE 431"]],
    ["Winter 2022", ["CSE 341", "CSE 344", "CSE 421", "CSE 444"]]
  ]);
