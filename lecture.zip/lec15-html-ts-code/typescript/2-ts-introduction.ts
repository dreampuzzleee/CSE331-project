/*
This example file introduces some of the basic features of TypeScript.

See README.md for instructions on how to run this file.

In this file, any line that would cause a compiler error is commented out and
indicated as such, to allow this file to be compiled even though we're demonstrating
compiler errors.
*/





// Variables are introduced with const and let
// const means the variable cannot be reassigned after creating it, let allows reassignment
const courseNum: number = 331;
// courseNum = courseNum + 5; // <- Error

let schoolName: string = "The Allen School";
schoolName += " of Computer Science";

// Also other basic types available:
const george: boolean = true;
const nullValue: null = null;
const unset: undefined = undefined;
//let unset; //also be undefined

// TypeScript has "any" type - this makes it behave like JavaScript - variables can change types whenever
// This is _dangerous), you're turning off the type system and losing all the safety
// Therefore, using "any" should be rare, and well-thought-out
let dangerous: any = 5;
dangerous = "abc";
dangerous = true;

// console.log is the equivalent of System.out.println
// Strings can begin with double or single quotes (see above)
// ...or they can use `backticks`, which allows you to do ${interpolation}.
console.log(`CSE ${courseNum} is the best course at ${schoolName}`);

//terminal - tsc folder-name.ts - to complie into js file
// node folder-name.js to run javascript files



// Equality is different than Java
// Double equal: == and != do conversions between types (it _tries_ to make them equal, if it can)
// Triple equal: === and !== don't convert, just compare
// Good practice: Always use triple-equal, double equal can be dangerous

// @ts-ignore
console.log('7 == "7"', 7 == "7"); // true
// @ts-ignore
console.log('7 === "7"', 7 === "7"); // false
// (note - we put @ts-ignore here because typescript will complain about
// us breaking rules like this, but we still want to demonstrate them
// you should _never_ need to ts-ignore in your own code)





// Can create arrays of any type:
const arrayOfNumbers: number[] = [1, 2, 3, 4, 5];
// Or arrays that allow multiple types:
const arrayOfMixed: (number | boolean)[] = [1, true, 3, 4, false];
// Or arrays with specific rules about length and types (called "tuples")
const tuple: [number, string, boolean] = [1, "hello", false];

// No index checking (for positive indices)
let shortArray = [0, 1];
shortArray[5] = 5;
console.log("shortArray", shortArray); // [0, 1, undefined, undefined, undefined, 5];

// Arrays can behave like stacks, queues, lists, etc...
// They are _not_ fixed-size
const arr: number[] = [0, 1, 2];
arr.push(3); // [0, 1, 2, 3]
const three = arr.pop(); // (arr is now [0, 1, 2])
arr.reverse(); // [2, 1, 0]





// We can use loops and if statements, same as you'd expect
// Not shown here: while loops, for-of and for-in loops (be careful about which one you use)
let numPositives = 0;
const nums: number[] = [1, -4, 28, 331, -26]
for (let i = 0; i < nums.length; i++) {
    if (nums[i] > 0) {
        numPositives++;
    }
}
console.log("numPositives", numPositives); // 3





// Functions are created like so:
// With TypeScript, you can specify the parameter types and the return type
function average(a: number, b: number): number {
    return (a + b) / 2;
}

let sixPointFive = average(6, 7);
// TypeScript will check for type errors in function calls:
// average("6", "7"); // <- Error

// TypeScript can infer the types of variables based on context:
// sixPointFive = "some string"; // <- Error





function averageAny(a, b) { // If we don't specify types, the default type is 'any' since it can't be inferred
    // JavaScript behavior: with two incompatible types, it'll try its best to convert them
    return (a + b) / 2;
}

console.log('averageAny("6", "7")', averageAny("6", "7")); // 33.5!!
// This is one reason why you want to use the type system available to you - avoid these bugs!





// We can also create "arrow functions" - alternative way of creating them.
// We're letting TypeScript infer 'number' as the return type, but we could also write it explicitly
// (Note - there's a technical difference between arrow and non-arrow functions. We'll discuss later.)
const averageArrow = (a: number, b: number) => (a + b) / 2;
console.log("averageArrow(6, 7)", averageArrow(6, 7)); // 6.5

// (All) Functions are values - you can store them in variables, pass them around as arguments, etc..
const otherAverage = average;
console.log("otherAverage(6, 7)", otherAverage(6, 7)); // 6.5

// This function takes a function as a parameter.
// The type of the parameter is (n: number) => number
// In typescript, function types look like arrow functions
// (n: number) => number means "A function that takes one number argument and returns a number"
function callWithSeven(func: (n: number) => number): number {
    return func(7);
}

function addOne(n: number): number {
    return n + 1;
}

console.log("callWithSeven(addOne)", callWithSeven(addOne)); // 8

// Arrow functions don't need to be put into variables - you can use them right away:
const nine = callWithSeven((n: number) => n + 2);





// TypeScript lets us create new types to be shorthand for other types:
type NumberFunc = (n: number) => number;

const callWithEight = (func: NumberFunc): number => func(8);
console.log("callWithEight(addOne)", callWithEight(addOne));





// Objects in JS/TS are basically like HashMaps - simple key/value pairs
const simpleObj = { // TypeScript is inferring the type here
    school: "UW",
    colors: ["purple", "gold"],
    rank: 1,
};

// We can also write the type explicitly if we want:
const simpleObj2: { school: string, colors: string[], rank: number } = simpleObj;

// Typescript interfaces allow us to describe the shape of an object and give it a name.
// That shape becomes a new type - same shorthand as with "type NumberFunc" from above:
interface Point {
    x: number;
    y: number;
}
const center: Point = {x: 0, y: 0};

// Can interact with objects the way you would expect:
center.x = 5;
center.y++;

// Also have bracket notation:
center["x"] = 5;
center["y"]++;

// Which means you could do this...
const eks = "x";
center[eks] = 5;





// The values in objects can be functions, because functions are values! That's how we have instance methods:
interface PrintingPoint {
    x: number;
    y: number;
    print: () => string;
}

function printPoint() {
    // When <something>.printPoint() is called, the <something> becomes `this`
    return `(${this.x}, ${this.y})`;
}
const twoByTwo: PrintingPoint = {
    x: 2,
    y: 2,
    print: printPoint,
}
console.log("twoByTwo.print()", twoByTwo.print()); // (2, 2)
