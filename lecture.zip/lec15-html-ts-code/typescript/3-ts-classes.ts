/*
 This example file introduces some of the features of TypeScript that involve classes.

 See README.md for instructions on how to run this file.
 */

class Point {

  // These are fields:
  // "private readonly" is like Java's "private final"
  private readonly x: number;
  private readonly y: number;

  // Constructors in TypeScript use a slightly different syntax from Java
  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
  }

  distanceFromOrigin(): number {
    return Math.sqrt(this.x * this.x + this.y * this.y);
  }

  toString(): string {
    return `(${this.x}, ${this.y})`;
  }
}

const p1: Point = new Point(3, 4);
console.log(p1.distanceFromOrigin());  // 5





class ColoredPoint extends Point {

  private readonly color: string;

  constructor(x: number, y: number, color: string) {
    super(x, y);
    this.color = color;
  }

  toString(): string {
    return super.toString() + " - " + this.color;
  }
}

const coloredPoint: ColoredPoint = new ColoredPoint(3, 4, "yellow");
console.log(coloredPoint.distanceFromOrigin()); // 5





// When we call p1.toString(), we see that it accesses `this.x` and `this.y`.
// This is unsurprising - it's what we'd expect from a method call on an object.
// However, functions are values, which means we can do something like this:
const p1ToString = p1.toString;

// p1ToString is a function, so we can call it:
const p1String = p1ToString();

// However, p1String will be "(undefined, undefined)" instead of "(3, 4)".
// This is because, when we call p1ToString, we're just calling the function -
// it's not being called _on_ an object - we're not writing someObject.p1ToString(),
// just calling the function directly.
// Because of this, the `this` when the function is called is not `p1`, and so
// the function cannot access the values of x and y by using this.x and this.y.

// This is important whenever we're going to pass a function as a value to something
// else - that function might not work correctly if it needs to access `this` when
// it runs.

// To fix this, we can change the kind of function toString is. Right now, toString is
// a regular TS function. We can write it instead as an arrow function, though. Like
// this:

class Point2 {

  private readonly x: number;
  private readonly y: number;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
  }

  distanceFromOrigin(): number {
    return Math.sqrt(this.x * this.x + this.y * this.y);
  }

  // Arrow function.
  //   First, we create the function value () => {}
  //   Then, we store that value in a field `toString`
  toString = (): string => {
    return `(${this.x}, ${this.y})`;
  }

}

// While toString is an arrow function, it still works nearly the same as before:
const p2 = new Point2(3, 4);
console.log(p2.toString()); // (3, 4)

// The difference is that, with arrow functions, the value if `this` is "remembered",
// even if there's no object that the function is being called on. Like this:
const p2ToString = p2.toString;
const p2String = p2ToString();

// In this case, p2String will be what we expected: (3, 4).
// This is because the function remembers which object it was created within, even if
// it's being passed around as a value outside of that object.
// While this behavior might seem very odd, we'll see that this comes in handy
// when we're writing User Interface code to deal with things like buttons.





// While we're not going to look at these features closely in 331, TypeScript also has support for:
//  - public, private, and protected fields
//  - static fields
//  - abstract classes
