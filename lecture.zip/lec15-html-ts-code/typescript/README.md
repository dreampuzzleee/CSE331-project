To run, you must first convert the file to JS using TSC (TypeScript Compiler),
then you can run the JS using node.js (Node allows you to run JavaScript code
outside of a browser, directly on your machine.)

To install TypeScript, run `npm install` from the current directory. From then on,
you can use the TypeScript compiler. Note that `node` and `npm` must be installed
on your computer for this to work. You can install the LTS version of node from
nodejs.org, which also comes with npm automatically.

Steps to run:
1. npm install                (only once, to install TypeScript)
2. npx tsc [some-file].ts     (compile [some-file].ts into [some-file].js)
3. node [some-file].js        (run the code in [some-file].js)

As an alternative to running entire files, you can run `npx ts-node` to get
a TypeScript REPL, where you can try things out interactively. Note that this
command only works once you've run `npm install` in this directory.

Note - you need to have the file in the same folder as the package.json file
that came with it - they go together and both are needed to run the commands above.
